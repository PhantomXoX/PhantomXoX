<!-- SPYTROG -->
<p align='center'>
  <img src="https://github.com/7AXEL/SPYTROG/blob/main/img/logo.png"></img>
</p>
<p align='center'>
    <img src="https://img.shields.io/badge/SPYTROG-bg?style=for-the-badge;"></img>
</p>
<p align="center">
  <img src="https://img.shields.io/badge/SPYWARE TOOL V2.1-orange?style=for-the-badge;"></img>
</p>
<p align='center'>
  <img src="https://img.shields.io/badge/Author-A.X.E.L-red?style=flat-square;"></img>
  <img src="https://img.shields.io/badge/Open Source-Yes-magenta?style=flat-square;"></img>
  <img src="https://img.shields.io/badge/Written In-PYTHON-cyan?style=flat-square;"></img>
</p>
<p align='center'>
    <img src="https://img.shields.io/badge/DISCLAIMER-purple?style=for-the-badge;"></img>
    
#### SPYTROG
<img src='https://github.com/7AXEL/SPYTROG/blob/main/img/icon.ico'></img>
- spytrog tool is used to create windows virus 
- this virus will retrive all chrome saved password from the target pc
- to use it just install and run it and select 1 to build virus then enter your email adress and the tool will creat a zip file wish contain the virus log.exe and a config file main.cfg , note that this config file is used by the virus
- then you can build a fake app and include this virus in it by extracting the zip file in your app files and make your builten app run the virus when she is in execution
- when the virus was runned he will retrive chrome password from the pc who she is was runned into and he will send those password to your email in the spam section
#### INSTALLATION
- **`Windows`**
- > **`1`** download and install git for window from the original git website <a href='https://gitforwindows.org/'>download</a>
- > **`2`** download and install python3 from the original python website <a href='https://python.org'>download</a>
- > **`3`** start the git shell and run this commands:
```
git clone https://github.com/7AXEL/SPYTROG
```
- **`Linux`**
- > open the terminal and write those commands:
```
apt update & apt upgrade -y
apt install git python
git clone https://github.com/7AXEL/SPYTROG
```
#### RUN
- **`Window & Linux`**
```
cd SPYTROG
python spytrog.py
```
#### PLATFORMS
> Supported Platform : **`Windows`**, **`Ubuntu/Debian/Kali/Parrot/Arch Linux`**<br>
> Virus target platform : **`Windows`**
<hr>
